# ECE 625 Project - KNN Classification Objective 2 (Non Land)

# Loading in data
house_data=read.csv("non_land_V3.csv", stringsAsFactors = TRUE)
house_data$property_age_2015=as.numeric(house_data$property_age_2015)
house_data$building_count=as.numeric(house_data$building_count)
house_data$site_coverage=as.character(house_data$site_coverage)
house_data$site_coverage=as.numeric(house_data$site_coverage)
house_data$change_value_logical=as.factor(house_data$change_value_logical)
house_data = na.omit(house_data)
house_data_nonland = house_data
# Scaling the Assessed 2015 value
house_data_nonland[, c(18,19)] = apply(house_data_nonland[,c(18,19)], 2, scale)

# Library for KNN 
library(class)

# Standardizing the data for KNN

standardized.X = scale(house_data_nonland[,c(-3,-4,-5,-7,-8,-9,-10,-12,-13,-20)])

# Training and Test split

set.seed(1)
train = sample(1:nrow(house_data_nonland), nrow(house_data_nonland)*0.9) # 90% for training
test = (-train) # 10% for testing
train.X = standardized.X[train,]
test.X = standardized.X[test, ]
train.Y = house_data_nonland$change_value_logical[train]
test.Y  = house_data_nonland$change_value_logical[test]

# Fitting KNN

set.seed(1)
knn.pred_nonland = knn(train.X, test.X, train.Y, k = 10)

# Test error rate
mean(test.Y != knn.pred_nonland)

# Attempt cross validation

knn.cv_nonland = knn.cv(train.X, train.Y, k=10)
summary(knn.cv_nonland)
