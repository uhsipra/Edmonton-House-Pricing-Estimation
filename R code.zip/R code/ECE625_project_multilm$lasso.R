house_data=read.csv("non_land_V3.csv", stringsAsFactors = TRUE)
house_data$property_age_2015=as.numeric(house_data$property_age_2015)
house_data$building_count=as.numeric(house_data$building_count)
house_data$site_coverage=as.character(house_data$site_coverage)
house_data$site_coverage=as.numeric(house_data$site_coverage)
house_data$change_value_logical=as.factor(house_data$change_value_logical)
house_data = na.omit(house_data)

# Normalizing the assessed value for 2015 and 2016
house_data[, c(18,19)] = apply(house_data[, c(18,19)], 2, scale)

#plot(house_data)

# Training and test split
set.seed(432)
mlr_train = sample(1:nrow(house_data), nrow(house_data)*0.9)
mlr_test = (-mlr_train)
house_data_mlr_train = house_data[mlr_train,]
house_data_mlr_test = house_data[mlr_test,]

# Multiple linear regression
mlr.fit = glm(Assessed_value_2015~.-Assessed_value_2016-change_value_logical, 
          data=house_data[mlr_train,])
mlr.fit_lm = lm(Assessed_value_2015~.-Assessed_value_2016-change_value_logical,
              data=house_data[mlr_train,])
summary(mlr.fit)
summary(mlr.fit_lm)
library(car)
vif(mlr.fit_lm)
par(mfrow=c(2,2))
plot(mlr.fit_lm)
# From the diagnostic plots we can see that there appear to be a few outliars
# which we can remove to improve our fit and there is also a few high leverage
# points that can be taken out.

# use both ridge regression and the lasso method to select the optimal
# multiple linear regression model.

# The lasso
library(glmnet)
x = model.matrix(Assessed_value_2015~., data = house_data)[, c(-19,-20)]
y = house_data$Assessed_value_2015
set.seed(1)
train = sample(1:nrow(x), nrow(x)*0.9)
test = (-train)
x.train = x[train,]
y.train = y[train]
x.test = x[test, ]
y.test = y[test]
grid = 10^seq(12, -6, length=5000)
lasso.mod = glmnet(x[train, ], y[train], alpha=1)
set.seed(1)
cv.out = cv.glmnet(x[train, ], y[train], alpha=1)
bestlam = cv.out$lambda.min
lasso.pred = predict(lasso.mod, s=bestlam, newx=x[test,], type="coefficients")
lasso.pred@i
plot(y.test, lasso.pred_test)
plot(lasso.pred_test, residuals(lasso.mod))
title("The Lasso - Test set residuals")
plot(lasso.mod, xvar="lambda")
title("The Lasso Coefficients vs Lambda", line=2.5)

# We can create a plot of the CV errors vs lambda values
plot(cv.out$lambda, cv.out$cvm, main="CV error vs lambda values",
     type="l", xlim=c(0, 5e+5), ylim=c(8e+11,2e+12))
which.min(cv.out$cvm)
points(cv.out$lambda[which.min(cv.out$cvm)],
       cv.out$cvm[which.min(cv.out$cvm)],col="red")

# From the plotted CV error estimates, we can see that lasso picks a lambda
# value of 

# Ridge regression
library(glmnet)
ridge.mod = glmnet(x[train, ], y[train], alpha=0, lambda=grid)
set.seed(1)
cv.out_ridge = cv.glmnet(x[train, ], y[train], alpha=0, lambda=grid)
bestlam_ridge = cv.out_ridge$lambda.min
ridge.pred = predict(ridge.mod, s=bestlam_ridge, newx=x[test,], type="coefficients")
plot(y.test, ridge.pred_values)
plot(ridge.pred_test, residuals(ridge.mod))
title("Ridge Regression - Test set residuals")

# We can create a plot of the CV errors vs lambda values
plot(cv.out_ridge$lambda, cv.out_ridge$cvm, main="CV error vs lambda values",
     type="l", xlim=c(0, 10e+5), ylim=c(8e+10,2e+12))
which.min(cv.out_ridge$cvm)
points(cv.out_ridge$lambda[which.min(cv.out_ridge$cvm)],
       cv.out_ridge$cvm[which.min(cv.out_ridge$cvm)],col="red")


# Evaluating the model fits

# Multiple Linear Regression
# Training MSE
mlr.pred_train = predict(mlr.fit)
mlr_train_MSE = mean((mlr.pred_train - house_data_mlr_train$Assessed_value_2015)^2)
mlr_train_RSS = sum((mlr.pred_train - house_data_mlr_train$Assessed_value_2015)^2)
mlr_train_SST = sum((house_data_mlr_train$Assessed_value_2015 - 
                       mean(house_data_mlr_train$Assessed_value_2015))^2)
mlr_train_rsquare = 1 - (mlr_train_RSS / mlr_train_SST)
# Test MSE
mlr.pred_test = predict(mlr.fit, newdata = house_data[mlr_test,])
mlr_test_MSE = mean((mlr.pred_test - house_data_mlr_test$Assessed_value_2015)^2)
mlr_test_RSS = sum((mlr.pred_test - house_data_mlr_test$Assessed_value_2015)^2)
mlr_test_SST = sum((house_data_mlr_test$Assessed_value_2015 - 
                       mean(house_data_mlr_test$Assessed_value_2015))^2)
mlr_test_rsquare = 1 - (mlr_test_RSS / mlr_test_SST)

# Ridge Regression
# Training MSE
ridge.pred_train = predict(ridge.mod, s=bestlam_ridge, newx=x[train,])
ridge_train_MSE = mean((ridge.pred_train - y.train)^2)
ridge_train_RSS = sum((ridge.pred_train - y.train)^2)
ridge_train_SST = sum((y.train - mean(y.train))^2)
ridge_train_rsquare = 1 - (ridge_train_RSS / ridge_train_SST)
# Test MSE
ridge.pred_test = predict(ridge.mod, s=bestlam_ridge, newx=x[test,])
ridge_test_MSE = mean((ridge.pred_test-y.test)^2)
ridge_test_RSS = sum((ridge.pred_test - y.test)^2)
ridge_test_SST = sum((y.test - mean(y.test))^2)
ridge_test_rsquare = 1 - (ridge_test_RSS / ridge_test_SST)

# The Lasso
# Training MSE
lasso.pred_train = predict(lasso.mod, s=bestlam, newx=x[train,])
lasso_train_MSE = mean((lasso.pred_train-y.train)^2)
lasso_train_RSS = sum((lasso.pred_train - y.train)^2)
lasso_train_SST = sum((y.train - mean(y.train))^2)
lasso_train_rsquare = 1 - (lasso_train_RSS / lasso_train_SST)
# Test MSE
lasso.pred_test = predict(lasso.mod, s=bestlam, newx=x[test,])
lasso_test_MSE = mean((lasso.pred_test-y.test)^2)
lasso_test_RSS = sum((lasso.pred_test - y.test)^2)
lasso_test_SST = sum((y.test - mean(y.test))^2)
lasso_test_rsquare = 1 - (lasso_test_RSS / lasso_test_SST)


# Plots of the models

# Multiple linear regression
# Test set residuals
plot(mlr.pred_test - house_data_mlr_test$Assessed_value_2015
     , ylab="Residuals")
abline(0,0, col="red")
title("Multiple Linear Regression - Test set residuals (Non land)")
legend("topright", inset=c(-0.04,0.07), 
       legend=paste("MSE", c("Test: 0.6204", "Train: 0.6669")), xpd=TRUE)
legend("bottomright", inset=c(-0.04,0.07), 
       legend=paste("R-Square", c("Test: 0.6332", "Train: 0.2776")), xpd=TRUE)

# Ridge Regression
# CV error plot
plot(cv.out_ridge, xlim=c(-11,0), ylim=c(0,0.1))
title("CV error vs Lambda values - Ridge Regression (Non land)", line=2.5)
# Test set residuals
plot(ridge.pred_test-y.test, ylab="Residuals")
abline(0,0, col="red")
title("Ridge Regression - Test set residuals (Non land)")
legend("topright", inset=c(-0.04,0.07), 
       legend=paste("MSE", c("Test: 0.00286", "Train: 0.00387")), xpd=TRUE)
legend("bottomright", inset=c(-0.04,0.07), 
       legend=paste("R-Square", c("Test: 0.9819", "Train: 0.9965")), xpd=TRUE)
# Coefficient plot
plot(ridge.mod, xvar="lambda")
abline(v=log(bestlam_ridge), col="red", lwd=2)
title("Ridge Regression Coefficients vs Lambda (Non land)", line=2.5)
legend("topleft", inset=c(0.01,0.01), 
       legend=paste("Optimal Lambda: 6.058E-5"), xpd=TRUE)

# The Lasso
# CV error plot
plot(cv.out)
title("CV error vs Lambda values - The Lasso (Non land)", line=2.5)
# Test set residuals
plot(lasso.pred_test-y.test, ylab="Residuals")
abline(0,0, col="red")
title("The Lasso - Test set residuals (Non land)")
legend("topright", inset=c(-0.04,0.07), 
       legend=paste("MSE", c("Test: 0.00264", "Train: 0.00401")), xpd=TRUE)
legend("bottomright", inset=c(-0.04,0.07), 
       legend=paste("R-Square", c("Test: 0.98334", "Train: 0.9963")), xpd=TRUE)
# Coefficient plot
plot(lasso.mod, xvar="lambda", xlim=c(-6.5,-4))
abline(v=log(bestlam), col="red", lwd=2)
title("The Lasso Coefficients vs Lambda (Non land)", line=2.5)
legend("bottomright", inset=c(0.01,0.01), 
       legend=paste("Optimal Lambda: 1.699E-3"), xpd=TRUE)
