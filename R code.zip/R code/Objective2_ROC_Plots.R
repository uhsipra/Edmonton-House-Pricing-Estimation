# ECE625 Project ROC plots

# land without 2015

# SVM

rocplot(svm.pred_linear_ROC_land_no2015, house_data_land.test_no2015$change, col="black")

rocplot(svm.pred_radial_ROC_land_no2015, house_data_land.test_no2015$change, add=T, col="red")

rocplot(svm.pred_poly_ROC_land_no2015, house_data_land.test_no2015$change, add=T, col="blue")

# Logistic regression

rocplot(prob.test_land2,land$change[-train_l],add=T,col="green")

# LDA & QDA

rocplot(landqda.test2$posterior[,2],land$change[-land.train],add=T,col="gray")

rocplot(landlda.test2$posterior[,2],land$change[-land.train],add=T,col="orange")

title("Test Set ROC Plots (Land): Excluding 2015 assessed values")
abline(0,1, lty=3)
legend("bottomright", legend=c("Support Vector Classifier (SVM Linear Kernel", 
                           "SVM Radial Kernel",
                           "SVM Polynomial Kernel degree 3", 
                           "Logistic Regression", "LDA","QDA"
                           ),
       col=c("black","red","blue","green","gray","orange"),
       lty=1,cex=0.8, xpd=TRUE)


# Land with 2015

# SVM

rocplot(svm.pred_linear_ROC_land, house_data_land.test$change, col="black")

rocplot(svm.pred_radial_ROC_land, house_data_land.test$change, add=T, col="red")

rocplot(svm.pred_poly_ROC_land, house_data_land.test$change, add=T, col="blue")

# Logistic regression

rocplot(prob.test_land,land$change[-train_l],add=T,col="green")

# LDA & QDA

rocplot(landlda.test$posterior[,2],land$change[-land.train],add=T,col="gray")

rocplot(landqda.test$posterior[,2],land$change[-land.train],add=T,col="orange")

title("Test Set ROC Plots (Land): Including 2015 assessed values")
abline(0,1, lty=3)
legend("bottomright", legend=c("Support Vector Classifier (SVM Linear Kernel", 
                               "SVM Radial Kernel",
                               "SVM Polynomial Kernel degree 3", 
                               "Logistic Regression", "LDA","QDA"
),
col=c("black","red","blue","green","gray","orange"),
lty=1,cex=0.8, xpd=TRUE)

# nonland without 2015

# Logistic regression

rocplot(prob.test2,nonland$change[-train],col="black")

# LDA & QDA

rocplot(lda.test2$posterior[,2],nonland$change[-train],add=T,col="red")

rocplot(qda.test4$posterior[,2],nonland$change[-train],add=T,col="blue")

title("Test Set ROC Plots (Nonland): Excluding 2015 assessed values")
abline(0,1, lty=3)
legend("bottomright", legend=c( "Logistic Regression", "LDA","QDA"),
col=c("black","red","blue"),
lty=1,cex=0.8, xpd=TRUE)


# Nonland with 2015

# Logistic regression

rocplot(prob.test,nonland$change[-train], col="black")

# LDA & QDA

rocplot(lda.test$posterior[,2],change.2016, add=T, col="red")

rocplot(qda.test3$posterior[,2],nonland$change[-train],add=T,col="blue")

title("Test Set ROC Plots (Nonland): Including 2015 assessed values")
abline(0,1, lty=3)
legend("bottomright", legend=c( "Logistic Regression", "LDA","QDA"),
       col=c("black","red","blue"),
       lty=1,cex=0.8, xpd=TRUE)
