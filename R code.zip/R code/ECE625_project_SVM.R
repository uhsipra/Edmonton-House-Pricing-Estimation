# ECE 625 Project - SVM (Non Land)

# Loading in data
house_data=read.csv("non_land_V3.csv", stringsAsFactors = TRUE)
house_data$property_age_2015=as.numeric(house_data$property_age_2015)
house_data$building_count=as.numeric(house_data$building_count)
house_data$site_coverage=as.character(house_data$site_coverage)
house_data$site_coverage=as.numeric(house_data$site_coverage)
house_data$change_value_logical=as.factor(house_data$change_value_logical)
house_data = na.omit(house_data)
house_data_nonland = house_data
# Scaling the Assessed 2015 value
house_data_nonland[, c(18,19)] = apply(house_data_nonland[,c(18,19)], 2, scale)

# The "e1071" library is used to fit SVM
library(e1071)

# Separating of training and test data
set.seed(1)
train = sample(1:nrow(house_data_nonland), nrow(house_data_nonland)*0.9) # 90% for training
test = (-train) # 10% for testing
house_data_nonland.train = house_data_nonland[train,]
house_data_nonland.test = house_data_nonland[test, ]

# With 2015 assessed value as a feature ################

# Linear kernel aka support vector classifier

# Fitting linear kernel with cost = 5000

svmfit_linear_nonland = svm(change_value_logical~., data=house_data_nonland.train, 
                            kernel="vanilladot", C = 200)

# Calculating error rates

# Test error

svmpred.linear_nonland_test = 
  predict(svmfit_linear_nonland, house_data_nonland.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear_nonland_test, truth=house_data_nonland.test$change)
# We can also determine the test error rate
svm_linear_nonland_test_error_rate = 
  mean(svmpred.linear_nonland_test != house_data_nonland.test$change)

svm_linear_nonland_test_error_rate

# Training error

svmpred.linear_nonland_train = 
  predict(svmfit_linear_nonland, house_data_nonland.train)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear_nonland_train, truth=house_data_nonland.train$change)
# We can also determine the test error rate
svm_linear_nonland_train_error_rate =
  mean(svmpred.linear_nonland_train != house_data_nonland.train$change)

svm_linear_nonland_train_error_rate

# Cost value of 200
# The training error rate was 17.61%% and test error rate was 17.66%.

# Radial Kernel

svmfit_radial_nonland = svm(change_value_logical~., data=house_data_nonland.train, 
                            kernel="radial", cost = 2000)

# Calculating error rates

# Test error

svmpred.radial_nonland_test = 
  predict(svmfit_radial_nonland, house_data_nonland.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.radial_nonland_test, truth=house_data_nonland.test$change)
# We can also determine the test error rate
svm_radial_nonland_test_error_rate = 
  mean(svmpred.radial_nonland_test != house_data_nonland.test$change)

svm_radial_nonland_test_error_rate

# Training error

svmpred.radial_nonland_train = 
  predict(svmfit_radial_nonland, house_data_nonland.train)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.radial_nonland_train, truth=house_data_nonland.train$change)
# We can also determine the test error rate
svm_radial_nonland_train_error_rate =
  mean(svmpred.radial_nonland_train != house_data_nonland.train$change)

svm_radial_nonland_train_error_rate

# Cost value of 2000
# The training error rate was 13.16% and test error rate was 13.58%.

# Polynomial Kernel

svmfit_poly_nonland = svm(change_value_logical~., data=house_data_nonland.train, 
                          kernel="polynomial", degree=3, cost = 2000)

# Calculating error rates

# Test error

svmpred.poly_nonland_test = 
  predict(svmfit_poly_nonland, house_data_nonland.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.poly_nonland_test, truth=house_data_nonland.test$change)
# We can also determine the test error rate
svm_poly_nonland_test_error_rate = 
  mean(svmpred.poly_nonland_test != house_data_nonland.test$change)

svm_poly_nonland_test_error_rate

# Training error

svmpred.poly_nonland_train = 
  predict(svmfit_poly_nonland, house_data_nonland.train)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.poly_nonland_train, truth=house_data_nonland.train$change)
# We can also determine the test error rate
svm_poly_nonland_train_error_rate =
  mean(svmpred.poly_nonland_train != house_data_nonland.train$change)

svm_poly_nonland_train_error_rate

# Cost value of 2000 with the degree = 3
# The training error rate was 19.90%% and test error rate was 19.90%.

# ROC Plots

# Linear kernel

svmfit_linear_ROC_nonland = svm(change_value_logical~., data=house_data_nonland.train, 
                                 kernel="linear", cost = 1000, probability=T)

svm.pred_linear_ROC_nonland = attr(predict(svmfit_linear_ROC_nonland, 
                                           house_data_nonland.test, probability=TRUE),'probabilities')[,2]

rocplot(svm.pred_linear_ROC_nonland, house_data_nonland.test$change, col=1)

# Radial kernel

svmfit_radial_ROC_nonland = svm(change ~., data=house_data_nonland.train, 
            kernel="radial", cost=5000, probability=TRUE)

svm.pred_radial_ROC_nonland = attr(predict(svmfit_radial_ROC_nonland_no2015, 
            house_data_nonland.test, probability=TRUE),'probabilities')[,2]

rocplot(svm.pred_radial_ROC_nonland, house_data_nonland.test$change, add=T, col=2)

# Polynomial kernel

svmfit_poly_ROC_nonland = svm(change ~., data=house_data_nonland.train, 
                kernel="polynomial", degree=3, cost=10000, probability=TRUE)

svm.pred_poly_ROC_nonland = attr(predict(svmfit_poly_ROC_nonland, 
                house_data_nonland.test, probability=TRUE),'probabilities')[,2]

rocplot(svm.pred_poly_ROC_nonland, house_data_nonland.test$change, add=T, col=3)

abline(0,1, lty=3)
title("SVM Test Set ROC Plots (Land)")
legend("bottomright", 
       legend=paste("SVM Kernel", 
                    c("Linear (Aka support vector classifier)", 
                      "Radial", 
                      "Polynomial degree 3")), 
       xpd=TRUE, fill=1:3)

# We make predictions using our test data
svmpred.linear = predict(svmfit.linear, house_data.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear, truth=house_data.test$change_value_logical)
# We can also determine the test error rate
mean(svmpred.linear != house_data.test$change_value_logical)
# With a cost value of 1, the linear kernel SVM achieves a test error rate of
# 18.89%.

# Attempting cross validation
set.seed(1)
# Because SVM is very computationally heavy, we have picked a random sample of
# observations to perform cross-validation to pick the ideal cost value. 
# Then we will fit the entire training data set with the cost value and make 
# our predictions on the test data set.

cv.sample500 = sample(1:nrow(house_data), size = 500)
cv.sample5000 = sample(1:nrow(house_data), size = 5000)
tuneout.svmfit.linear = tune(svm, change_value_logical~., 
                             data=house_data[cv.sample500,], 
                             kernel="linear", ranges=list(cost=c(0.01,1,2,5,10,100,150,300)))
# With a random sample size of 500 observations, cross validation gave us an 
# optimal cost value of 2.01 for the linear kernel.

tuneout.svmfit.linear5000 = tune(svm, change_value_logical~., 
                                 data=house_data[cv.sample5000,], 
                                 kernel="linear", ranges=list(cost=c(0.001, 0.01, 0.1, 1, 2, 5, 10, 100)))

summary(tuneout.svmfit.linear)


# K-fold cross validation on various cost values
k = 10
n = nrow(house_data.train)
set.seed(1)
# The below code will randomly assign "n" observations to belong in
# one of the k folds for cross validation
folds = sample(rep(1:k, length=n))
cv.errors = matrix(NA, k, 8, dimnames=list(NULL, paste(1:8)))
cv.errors.cost = seq(0.1, 5.1, by=0.01)

for (j in 1:k) {
  column = 0
  for (i in c(0.001, 0.01, 0.1, 1, 2, 5, 10, 100) ) {
    column = column+1
    svmfit.linear_cv = ksvm(change_value_logical~., data=house_data.train[folds!=j,], 
                            kernel="vanilladot", C = i)
    svmpred.linear_cv = predict(svmfit.linear_cv, house_data.train[folds==j, ])
    # Some predicted values have "NA" so we will remove them from consideration
    # when calculating the CV errors.
    NA.vals = is.na(svmpred.linear_cv)
    cv.errors[j,column] = mean(svmpred.linear_cv != 
                                 house_data.train$change_value_logical[folds==j])
  }
}
mean.cv.errors = apply(cv.errors,2,mean)
plot(c(0.001, 0.01, 0.1, 1, 2, 5, 10, 100), mean.cv.errors, type="l",
     xlab="Cost", ylab="K-fold CV error", 
     main="CV Error vs Increasing Cost - SVM Linear kernel")


# Fitting the support vector classier with cost = 100
svmfit.linear = ksvm(change_value_logical~., data=house_data.train, 
                     kernel="vanilladot", C = 100)

# We make predictions using our test data
svmpred.linear = predict(svmfit.linear, house_data.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear, truth=house_data.test$change_value_logical)
# We can also determine the test error rate
mean(svmpred.linear != house_data.test$change_value_logical)
# With a cost value of 100, the linear kernel SVM achieves a test error rate of
# 10.47%.


# Fitting the support vector classier with cost = 200
svmfit.linear200 = ksvm(change_value_logical~., data=house_data.train, 
                        kernel="vanilladot", C = 200)

# We make predictions using our test data
svmpred.linear200 = predict(svmfit.linear200, house_data.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear200, truth=house_data.test$change_value_logical)
# We can also determine the test error rate
mean(svmpred.linear200 != house_data_nonland.test$change_value_logical)
# With a cost value of 200, the linear kernel SVM achieves a test error rate of
# %.


# K-fold cross validation on various cost values with sample of 500 observations
set.seed(1)
sample500 = sample(1:nrow(house_data.train), size = 500)
k = 10
n = 500
set.seed(1)
# The below code will randomly assign "n" observations to belong in
# one of the k folds for cross validation
folds = sample(rep(1:k, length=n))
cv.errors500 = matrix(NA, k, 8, dimnames=list(NULL, paste(1:8)))

for (j in 1:k) {
  column = 0
  for (i in c( 0.01, 0.1, 1, 2, 5, 10, 100, 200) ) {
    column = column+1
    svmfit.linear_cv500 = ksvm(change_value_logical~., data=house_data.train[sample500,][folds!=j,], 
                               kernel="vanilladot", C = i)
    svmpred.linear_cv500 = predict(svmfit.linear_cv500, house_data.train[sample500,][folds==j,])
    # Some predicted values have "NA" so we will remove them from consideration
    # when calculating the CV errors.
    NA.vals = is.na(svmpred.linear_cv500)
    cv.errors500[j,column] = mean(svmpred.linear_cv500 != 
                                    house_data.train[sample500,]$change_value_logical[folds==j])
  }
}
mean.cv.errors500 = apply(cv.errors500,2,mean)
plot(c( 0.01, 0.1, 1, 2, 5, 10, 100, 200), mean.cv.errors500, type="l",
     xlab="Cost", ylab="K-fold CV error", 
     main="CV Error vs Increasing Cost - SVM Linear kernel(500 samples)")