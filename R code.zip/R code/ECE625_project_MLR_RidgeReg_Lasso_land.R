house_data=read.csv("land_V3.csv", stringsAsFactors = TRUE)
house_data = na.omit(house_data)
# Scaling the Assessed 2015 value
house_data[, c(12,13)] = apply(house_data[,c(12,13)], 2, scale)
house_data = house_data[,c(-13,-14)] #2016 assessed, and change.

# Multiple linear regression

# Training and test split
set.seed(335)
mlr_train = sample(1:nrow(house_data), nrow(house_data)*0.9)
mlr_train_land = mlr_train # This is the proper seed training set for land data
mlr_test = (-mlr_train)
house_data_mlr_train = house_data[mlr_train,]
house_data_mlr_test = house_data[mlr_test,]

# Fitting MLR models
mlr.fit = glm(Assessed_value_2015~. ,data=house_data[mlr_train,])
mlr.fit_lm = lm(Assessed_value_2015~. ,data=house_data[mlr_train,])
summary(mlr.fit)
summary(mlr.fit_lm)
par(mfrow=c(2,2))
plot(mlr.fit_lm)

# Extra diagnostic stuff
library(car)
vif(mlr.fit_lm)
par(mfrow=c(2,2))
plot(mlr.fit_lm)
# From the diagnostic plots we can see that there appear to be a few outliars
# which we can remove to improve our fit and there is also a few high leverage
# points that can be taken out.

# use both ridge regression and the lasso method to select the optimal
# multiple linear regression model.


# The lasso
library(glmnet)
x = model.matrix(Assessed_value_2015~., data = house_data)
y = house_data$Assessed_value_2015
set.seed(1)
train = sample(1:nrow(x), nrow(x)*0.9)
test = (-train)
x.train = x[train,]
y.train = y[train]
x.test = x[test, ]
y.test = y[test]
# The grid is optional
grid = 10^seq(12, -6, length=5000)
lasso.mod = glmnet(x[train, ], y[train], alpha=1)
set.seed(1)
cv.out = cv.glmnet(x[train, ], y[train], alpha=1)
bestlam = cv.out$lambda.min

# We can create a plot of the CV errors vs lambda values
plot(cv.out$lambda, cv.out$cvm, main="CV error vs lambda values",
     type="l", xlim=c(0, 5e+5), ylim=c(8e+11,2e+12))
which.min(cv.out$cvm)
points(cv.out$lambda[which.min(cv.out$cvm)],
       cv.out$cvm[which.min(cv.out$cvm)],col="red")


# Ridge regression
library(glmnet)
ridge.mod = glmnet(x[train, ], y[train], alpha=0)
set.seed(1)
cv.out_ridge = cv.glmnet(x[train, ], y[train], alpha=0)
bestlam_ridge = cv.out_ridge$lambda.min

# We can create a plot of the CV errors vs lambda values
plot(cv.out_ridge$lambda, cv.out_ridge$cvm, main="CV error vs lambda values",
     type="l", xlim=c(0, 10e+5), ylim=c(8e+10,2e+12))
which.min(cv.out_ridge$cvm)
points(cv.out_ridge$lambda[which.min(cv.out_ridge$cvm)],
       cv.out_ridge$cvm[which.min(cv.out_ridge$cvm)],col="red")

# KNN Regression
Library(FNN)



# Evaluating the model fits

# Multiple Linear Regression
# Training MSE
mlr.pred_train = predict(mlr.fit)
mlr_train_MSE = mean((mlr.pred_train - house_data_mlr_train$Assessed_value_2015)^2)
mlr_train_RSS = sum((mlr.pred_train - house_data_mlr_train$Assessed_value_2015)^2)
mlr_train_SST = sum((house_data_mlr_train$Assessed_value_2015 - 
                       mean(house_data_mlr_train$Assessed_value_2015))^2)
mlr_train_rsquare = 1 - (mlr_train_RSS / mlr_train_SST)
# Test MSE
mlr.pred_test = predict(mlr.fit, newdata = house_data[mlr_test,])
mlr_test_MSE = mean((mlr.pred_test - house_data_mlr_test$Assessed_value_2015)^2)
mlr_test_RSS = sum((mlr.pred_test - house_data_mlr_test$Assessed_value_2015)^2)
mlr_test_SST = sum((house_data_mlr_test$Assessed_value_2015 - 
                      mean(house_data_mlr_test$Assessed_value_2015))^2)
mlr_test_rsquare = 1 - (mlr_test_RSS / mlr_test_SST)

# Ridge Regression
# Training MSE
ridge.pred_train = predict(ridge.mod, s=bestlam_ridge, newx=x[train,])
ridge_train_MSE = mean((ridge.pred_train - y.train)^2)
ridge_train_RSS = sum((ridge.pred_train - y.train)^2)
ridge_train_SST = sum((y.train - mean(y.train))^2)
ridge_train_rsquare = 1 - (ridge_train_RSS / ridge_train_SST)
# Test MSE
ridge.pred_test = predict(ridge.mod, s=bestlam_ridge, newx=x[test,])
ridge_test_MSE = mean((ridge.pred_test-y.test)^2)
ridge_test_RSS = sum((ridge.pred_test - y.test)^2)
ridge_test_SST = sum((y.test - mean(y.test))^2)
ridge_test_rsquare = 1 - (ridge_test_RSS / ridge_test_SST)

# The Lasso
# Training MSE
lasso.pred_train = predict(lasso.mod, s=bestlam, newx=x[train,])
lasso_train_MSE = mean((lasso.pred_train-y.train)^2)
lasso_train_RSS = sum((lasso.pred_train - y.train)^2)
lasso_train_SST = sum((y.train - mean(y.train))^2)
lasso_train_rsquare = 1 - (lasso_train_RSS / lasso_train_SST)
# Test MSE
lasso.pred_test = predict(lasso.mod, s=bestlam, newx=x[test,])
lasso_test_MSE = mean((lasso.pred_test-y.test)^2)
lasso_test_RSS = sum((lasso.pred_test - y.test)^2)
lasso_test_SST = sum((y.test - mean(y.test))^2)
lasso_test_rsquare = 1 - (lasso_test_RSS / lasso_test_SST)


# Plots of the models

# Multiple linear regression
# Test set residuals
plot(mlr.pred_test - house_data_mlr_test$Assessed_value_2015
     , ylab="Residuals")
abline(0,0, col="red")
title("Multiple Linear Regression - Test set residuals (Land)")
legend("topright", inset=c(-0.04,0.07), 
       legend=paste("MSE", c("Test: 0.7619", "Train: 0.6625")), xpd=TRUE)
legend("bottomright", inset=c(-0.04,0.07), 
       legend=paste("R-Square", c("Test: 0.1203", "Train: 0.3469")), xpd=TRUE)

plot(house_data_mlr_test$Assessed_value_2015, mlr.pred_test)

# Ridge Regression
# CV error plot
plot(cv.out_ridge)
title("CV error vs Lambda values - Ridge Regression (Land)", line=2.5)
# Test set residuals
plot(ridge.pred_test-y.test, ylab="Residuals")
abline(0,0, col="red")
title("Ridge Regression - Test set residuals (Land)")
legend("topright", inset=c(-0.04,0.07), 
       legend=paste("MSE", c("Test: 0.9749", "Train: 0.6602")), xpd=TRUE)
legend("bottomright", inset=c(-0.04,0.07), 
       legend=paste("R-Square", c("Test: 0.1285", "Train: 0.3308")), xpd=TRUE)
# Coefficient plot
plot(ridge.mod, xvar="lambda")
abline(v=log(bestlam_ridge), col="red", lwd=2)
title("Ridge Regression Coefficients vs Lambda (Land)", line=2.5)
legend("topleft", inset=c(0.01,0.01), 
       legend=paste("Optimal Lambda: 0.2211"), xpd=TRUE)

# The Lasso
# CV error plot
plot(cv.out)
title("CV error vs Lambda values - The Lasso (Land)", line=2.5)
# Test set residuals
plot(lasso.pred_test-y.test, ylab="Residuals")
abline(0,0, col="red")
title("The Lasso - Test set residuals (Land)")
legend("topright", inset=c(-0.04,0.07), 
       legend=paste("MSE", c("Test: 0.9747", "Train: 0.6530")), xpd=TRUE)
legend("bottomright", inset=c(-0.04,0.07), 
       legend=paste("R-Square", c("Test: 0.1287", "Train: 0.3380")), xpd=TRUE)
# Coefficient plot
plot(lasso.mod, xvar="lambda")
abline(v=log(bestlam), col="red", lwd=2)
title("The Lasso Coefficients vs Lambda (Land)", line=2.5)
legend("topleft", inset=c(0.01,0.01), 
       legend=paste("Optimal Lambda: 4.764E-3"), xpd=TRUE)
