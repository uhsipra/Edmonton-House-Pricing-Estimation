# ECE 625 Project - SVM (land)

# Loading in data
house_data_land=read.csv("land_V3.csv", stringsAsFactors = TRUE)
house_data_land = as.factor(house_data_land$change)
house_data_land = na.omit(house_data_land)
# Scaling the Assessed 2015 value
house_data_land[, c(12,13)] = apply(house_data_land[,c(12,13)], 2, scale)

# The "e1071" library is used to fit SVM
library(e1071)

# Separating of training and test data
set.seed(1)
train = sample(1:nrow(house_data_land), nrow(house_data_land)*0.9) # 90% for training
test = (-train) # 10% for testing
house_data_land.train = house_data_land[train,]
house_data_land.test = house_data_land[test, ]

# 2015 assessed value is a feature ######################

# Linear kernel aka support vector classifier
# Cross validation to determine the optimal cost value
tuneout.svmfit.linear_land = tune(svm, change~., 
               data=house_data_land.train, 
               kernel="linear", ranges=list(cost=c(500,2000,5000,2e+5,4e+6,8e+7,3e+11)))
summary(tuneout.svmfit.linear_land)
# Extracting the best model
svm_linear_bestmodel_land = tuneout.svmfit.linear_land$best.model

# Calculating error rates
# Test error
svmpred.linear_land_test = predict(svm_linear_bestmodel_land, house_data_land.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear_land_test, truth=house_data_land.test$change)
# We can also determine the test error rate
svm_linear_test_error_rate = mean(svmpred.linear_land_test != house_data_land.test$change)
svm_linear_test_error_rate

# Training error
svmpred.linear_land_train = predict(svm_linear_bestmodel_land, house_data_land.train)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear_land_train, truth=house_data_land.train$change)
# We can also determine the test error rate
svm_linear_train_error_rate = mean(svmpred.linear_land_train != house_data_land.train$change)
svm_linear_train_error_rate

# Cross Validation chose a optimal cost value of 5000
# The training error rate was 3.3859% and test error rate was 4.7917%

# Radial Kernel
# Cross validation to determine the optimal cost value
tuneout.svmfit.radial_land = tune(svm, change~., 
               data=house_data_land.train, 
               kernel="radial", ranges=list(cost=seq(1e+6,1e+8, length = 30)))
summary(tuneout.svmfit.radial_land)
# Extracting the best model
svm_radial_bestmodel_land = tuneout.svmfit.radial_land$best.model

# Calculating error rates
# Test error
svmpred.radial_land_test = predict(svm_radial_bestmodel_land, house_data_land.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM on the test data
table(predict=svmpred.radial_land_test, truth=house_data_land.test$change)
# We can also determine the test error rate
svm_radial_test_error_rate = mean(svmpred.radial_land_test != house_data_land.test$change)
svm_radial_test_error_rate

# Training error
svmpred.radial_land_train = predict(svm_radial_bestmodel_land, house_data_land.train)
# We can do the same for the training set
table(predict=svmpred.radial_land_train, truth=house_data_land.train$change)
# We can also determine the test error rate
svm_radial_train_error_rate = mean(svmpred.radial_land_train != house_data_land.train$change)
svm_radial_train_error_rate

# Cross Validation chose a optimal cost value of 4.414e+6 with the default gamma
# value. The training error rate was 1.299% and test error rate was 5.2083%

# Polynomial Kernel
# Cross validation to determine the optimal cost value
tuneout.svmfit.poly_land = tune(svm, change~., 
               data=house_data_land.train, degree=3, kernel="polynomial", 
               ranges=list(cost=c( 3e+10,6e+10,2e+11,8e+11,3e+12,7e+12,2e+13)))
tuneout.svmfit.poly_land_test = tune(svm, change~., 
               data=house_data_land.train, kernel="polynomial", degree=3,
               ranges=list(cost=c(0.01,1,2,5,10,100,150,300)))
summary(tuneout.svmfit.poly_land)
# Extracting the best model
svm_poly_bestmodel_land = tuneout.svmfit.poly_land$best.model

# Calculating error rates
# Test error rate
svmpred.poly_land_test = predict(svm_poly_bestmodel_land, house_data_land.test)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.poly_land_test, truth=house_data_land.test$change)
# We can also determine the test error rate
svm_poly_test_error_rate = mean(svmpred.poly_land_test != house_data_land.test$change)
svm_poly_test_error_rate

# Training error rate
svmpred.poly_land_train = predict(svm_poly_bestmodel_land, house_data_land.train)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.poly_land_train, truth=house_data_land.train$change)
# We can also determine the test error rate
svm_poly_train_error_rate = mean(svmpred.poly_land_train != house_data_land.train$change)
svm_poly_train_error_rate

# Cross Validation chose a optimal cost value of 3e+12 with the degree = 3
# The training error rate was 0.1623%% and test error rate was 9.7917%.


# ROC Plots
library(ROCR)
rocplot=function(pred, truth, ...){
  predob = prediction(pred, truth)
  perf = performance(predob, "tpr", "fpr")
  plot(perf,...)}


# Linear kernel
svmfit_linear_ROC_land = svm(change ~., data=house_data_land.train, kernel="linear", 
                             cost=5000, probability=TRUE)
svm.pred_linear_ROC_land = attr(predict(svmfit_linear_ROC_land, house_data_land.test,
                                        probability=TRUE),'probabilities')[,2]
rocplot(svm.pred_linear_ROC_land, house_data_land.test$change, col=1)

# Radial kernel
svmfit_radial_ROC_land = svm(change ~., data=house_data_land.train, kernel="radial", 
                             cost=4.414e+6, probability=TRUE)
svm.pred_radial_ROC_land = attr(predict(svmfit_radial_ROC_land, house_data_land.test,
                                        probability=TRUE),'probabilities')[,2]
rocplot(svm.pred_radial_ROC_land, house_data_land.test$change, add=T, col=2)

# Polynomial kernel
svmfit_ploy_ROC_land = svm(change ~., data=house_data_land.train, kernel="polynomial", 
                             degree=3, cost=3e+12, probability=TRUE)
svm.pred_poly_ROC_land = attr(predict(svmfit_ploy_ROC_land, house_data_land.test,
                                        probability=TRUE),'probabilities')[,2]
rocplot(svm.pred_poly_ROC_land, house_data_land.test$change, add=T, col=3)

abline(0,1, lty=3)
title("SVM Test Set ROC Plots (Land)")
legend("bottomright", 
       legend=paste("SVM Kernel", 
       c("Linear (Aka support vector classifier)", 
         "Radial", 
         "Polynomial degree 3")), 
       xpd=TRUE, fill=1:3)




# Without 2015 assessed value as a feature ###############

# Removing 2015 assessed value as a feature
house_data_land.train_no2015 = house_data_land.train[,-12]
house_data_land.test_no2015 = house_data_land.test[,-12]

# SVC (Linear kernel)

svmfit_linear_land_no2015 = svm(change ~., data=house_data_land.train_no2015, 
              kernel="linear", cost=5000)
summary(svmfit_linear_land_no2015)
# Calculating error rates
# Test error
svmpred.linear_land_test_no2015 = 
  predict(svmfit_linear_land_no2015, house_data_land.test_no2015)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear_land_test_no2015,
      truth=house_data_land.test_no2015$change)
# We can also determine the test error rate
svm_linear_test_error_rate_no2015 = 
  mean(svmpred.linear_land_test_no2015 != house_data_land.test_no2015$change)
svm_linear_test_error_rate_no2015

# Training error
svmpred.linear_land_train_no2015 = 
  predict(svmfit_linear_land_no2015, house_data_land.train_no2015)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.linear_land_train_no2015, 
      truth=house_data_land.train_no2015$change)
# We can also determine the test error rate
svm_linear_train_error_rate_no2015 = 
  mean(svmpred.linear_land_train_no2015 != house_data_land.train_no2015$change)
svm_linear_train_error_rate_no2015

# With a cost value of 5000 the test error rate is 18.96% and the 
# training error rate is 16.72%

# Radial kernel

svmfit_radial_land_no2015 = svm(change ~., data=house_data_land.train_no2015, 
                                kernel="radial", cost=4.414e+6)

# Calculating error rates
# Test error
svmpred.radial_land_test_no2015 = 
  predict(svmfit_radial_land_no2015, house_data_land.test_no2015)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.radial_land_test_no2015,
      truth=house_data_land.test_no2015$change)
# We can also determine the test error rate
svm_radial_test_error_rate_no2015 = 
  mean(svmpred.radial_land_test_no2015 != house_data_land.test_no2015$change)
svm_radial_test_error_rate_no2015

# Training error
svmpred.radial_land_train_no2015 = 
  predict(svmfit_radial_land_no2015, house_data_land.train_no2015)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.radial_land_train_no2015, 
      truth=house_data_land.train_no2015$change)
# We can also determine the test error rate
svm_radial_train_error_rate_no2015 = 
  mean(svmpred.radial_land_train_no2015 != house_data_land.train_no2015$change)
svm_radial_train_error_rate_no2015

# With a cost value of 4.414e+6 the test error rate is 13.33% and the 
# training error rate is 6.05%

# Polynomial kernel

svmfit_poly_land_no2015 = svm(change ~., data=house_data_land.train_no2015, 
                              degree=3, kernel="polynomial", cost=3e+12)

# Calculating error rates
# Test error
svmpred.poly_land_test_no2015 = 
  predict(svmfit_poly_land_no2015, house_data_land.test_no2015)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.poly_land_test_no2015,
      truth=house_data_land.test_no2015$change)
# We can also determine the test error rate
svm_poly_test_error_rate_no2015 = 
  mean(svmpred.poly_land_test_no2015 != house_data_land.test_no2015$change)
svm_poly_test_error_rate_no2015

# Training error
svmpred.poly_land_train_no2015 = 
  predict(svmfit_poly_land_no2015, house_data_land.train_no2015)
# We can produce a confusion matrix to assess the performance of the linear
# kernel SVM
table(predict=svmpred.poly_land_train_no2015, 
      truth=house_data_land.train_no2015$change)
# We can also determine the test error rate
svm_poly_train_error_rate_no2015 = 
  mean(svmpred.poly_land_train_no2015 != house_data_land.train_no2015$change)
svm_poly_train_error_rate_no2015

# With a cost value of 3e+12 the test error rate is 15.42% and the 
# training error rate is 4.08%

# ROC Plots

# Linear kernel
svmfit_linear_ROC_land_no2015 = svm(change ~., data=house_data_land.train_no2015, 
                  kernel="linear", cost=5000, probability=TRUE)

svm.pred_linear_ROC_land_no2015 = attr(predict(svmfit_linear_ROC_land_no2015, 
                  house_data_land.test_no2015, probability=TRUE),'probabilities')[,2]

rocplot(svm.pred_linear_ROC_land_no2015, house_data_land.test_no2015$change, col=1)

# Radial kernel
svmfit_radial_ROC_land_no2015 = svm(change ~., data=house_data_land.train_no2015, 
                  kernel="radial", cost=4.414e+6, probability=TRUE)

svm.pred_radial_ROC_land_no2015 = attr(predict(svmfit_radial_ROC_land_no2015, 
                  house_data_land.test_no2015, probability=TRUE),'probabilities')[,2]

rocplot(svm.pred_radial_ROC_land_no2015, house_data_land.test_no2015$change, add=T, col=2)

# Polynomial kernel
svmfit_ploy_ROC_land_no2015 = svm(change ~., data=house_data_land.train_no2015, 
                  kernel="polynomial", degree=3, cost=3e+12, probability=TRUE)

svm.pred_poly_ROC_land_no2015 = attr(predict(svmfit_ploy_ROC_land_no2015, 
                  house_data_land.test_no2015, probability=TRUE),'probabilities')[,2]

rocplot(svm.pred_poly_ROC_land_no2015, house_data_land.test_no2015$change, add=T, col=3)

abline(0,1, lty=3)
title("SVM Test Set ROC Plots (Land): Excluding 2015 assessed values")
legend("bottomright", 
       legend=paste("SVM Kernel:", 
       c("Linear (Aka support vector classifier)", "Radial", "Polynomial degree 3")), 
       xpd=TRUE, fill=1:3)
